{
	"items":
	{
		"manage":
		{
			"items":
			{
				"eyeexam":
				{
                    "title": "Eye Exam Schedule",
                    "controller": "backend.eyeExamSchedule",
                    "role": "page",
                    "icon": "image/silk/page_white_text.png",
                    "descr": "Create and Eye Exam Schedule"
				}
			}
		}
	}
}

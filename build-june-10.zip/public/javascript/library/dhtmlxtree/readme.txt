dhtmlxTree JS Files Abbriviation Meaning:

dd - drag-n-drop
li - locked items extension
rl - right-to-left tree extension
sb - sorting
xw - xml related extension (serialization, cookies)
if - internal tree form
cgi - requested functionlity
kn - keyboard navigation
dd - extended drag-n-drop

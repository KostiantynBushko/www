<pre>Array
(
    [currentFolderPath] => ../uploaded/asdasd/
    [new_folder] => test11
)
</pre>

07/Feb/2010 01:56:11
<?php die(); ?>
gc start at 18/Jun/2010 15:17:30

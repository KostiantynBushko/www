<?php

/**
 * Custom error page
 * 
 * @package application
 */

header("HTTP/1.1 404 Not Found");

?>

<html>
<head>
	<title>Page not found</title>
</head>
<body>
	<h1>Page you are looking for is Not found!</h1>
	<p>
		Make sure you have entered URL correctly
	</p>
</body>
</html>
<?php

// array(pricePrefix, priceSuffix)
return array(

	'USD' => array('$'),
	'EUR' => array('', '€'),
	'CNY' => array('¥'),
	'JPY' => array('¥'),
	'GBP' => array('£'),
	'RUB' => array('', ' руб'),
	
);

?>